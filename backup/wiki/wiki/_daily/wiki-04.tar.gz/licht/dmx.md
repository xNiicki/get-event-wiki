---
title: DMX
description: 
published: 1
date: 2023-06-20T12:28:57.600Z
tags: dmx
editor: markdown
dateCreated: 2023-06-20T11:22:45.969Z
---

# DMX
Ein DMX-Universum hat 512 kanäle und fast unendlich DMX-Universen