---
title: Home
description: 
published: 1
date: 2023-02-17T10:39:31.153Z
tags: home
editor: markdown
dateCreated: 2023-02-15T17:26:52.322Z
---

# Wilkommen
Wilkommen auf den Wiki von GET-Event. 
Hier erfährst du z.B.

- Wie funktioniert Daslight?
- Wie Nutze ich das Tonpult?
- Wie ist die Aula Verkabelt?
- Welche "großen" Veranstaltungen haben wir jedes Jahr und wie laufen die ab?

## Themen

- [Ton*Übersichtseite Thema Ton*](/ton)
- [Licht*Übersicht zum Thema Licht*](/licht)
- [Aula*Übersicht der Aula*](/aula)
{.links-list}


