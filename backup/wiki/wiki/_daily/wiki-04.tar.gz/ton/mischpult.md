---
title: Mischpult
description: 
published: 1
date: 2023-02-16T17:10:39.314Z
tags: mischpult, ton
editor: markdown
dateCreated: 2023-02-15T18:03:32.683Z
---

# Mischpult

Es gibt 2 arten von Mischpulte. 

1. Analogpult
2. Digitalpult

Bei Mischpulte hast du mehrere kleine inputs die man zu einen großen output mischen kannst. Dabei kannst du die Lautstärke den Gain und den Equlizer anpassen. 
Wie dass bei unseren verschidenen Mischpulte funktioniert könnt ihr in den Unterthemen nachschauen

- [Großes Mischpult*Das was wir in der Regie stehen haben*](/ton/mischpult/groß)
- [Behringer X32 Compact*uner neues pult was wir hoffentlich bald bekommen*](/ton/mischpult/x32-compact)
- [Yamaha QL11*unser altes digitalpult*](ton/mischpult/yamaha-ql11)
{.links-list}