---
title: Mischpult Groß
description: 
published: 1
date: 2023-06-20T12:34:05.448Z
tags: groß, misch, to
editor: markdown
dateCreated: 2023-02-15T18:46:58.903Z
---

# Das Große Mischpult 

Schritt für Schritt erklärung des Mischpults. 

## Kanäle

Dieses mischpult hat 32 Kanäle und 2 Stereo Klinke Channel.
Außerdem hat das Pult Stereo Out 4 Buse und 4 XLR out/2 Klinke Out Ausgänge

> **ACHTUNG**: 1 Stereo Klinke Channel ist kaputt und 2 XLR eingänge. Außerdem sidn 2 Buse ausgänge kaputt
{.is-danger}


## Fader

Die Fader sind Analog. Das heißt dass keine Motoren dadrunter verbaut sind. Es gibt zu jeden Eingang 1 Fader. Dje Fader bestimmen wie viel Signal durchgehen soll. Je höher der Fader ist, desto Lauter ist das Signal


## Aux 

Die Aux knöpfe bestimmen, wie viel Signal durch die Aux Ausgänge geht. Hier gilt auch wieder die Regel je höher der Regler aufgedreht ist, desto mehr signal geht durch. 


## Equlizer 

Mit den EQ Lizer kann man die Höhen/Mitten/Tiefen einstellen. Hier haben wir für jede eistellung einen Regler. wenn der Regler in der Mitte ist, ist es Neutral. wenn der Regler nach links gedreht ist sind es z.b. weniger Tiefen. Wenn der regler aber nach Rechts gedreht ist, haben wir mehr Tiefen als Normal.

## 40V

der 40V knöpf ist dafür da, wenn du z.b ein Chor Mikrofon benutzt oder ein anderes was eine höhere stromspannung braucht. 

## Gain 

Mit den Gain veränderst du die EIngangslautstärke des Signals. Also genau wie deim Fader? Nein! Der Fader macht die Endlautstärke während der Gain die Eingangsläutstärke des Signals verändert.
![img_1924.jpeg](/img_1924.jpeg)

