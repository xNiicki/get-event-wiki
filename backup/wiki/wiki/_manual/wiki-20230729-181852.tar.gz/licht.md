---
title: licht
description: 
published: 1
date: 2023-02-16T17:09:12.598Z
tags: 
editor: markdown
dateCreated: 2023-02-15T18:00:05.398Z
---

# Wilkommen bei Licht
Hier findest du alles zu der Abteilung Licht

- [DMX*Digital Multiplex*](/licht/dmx)
{.links-list}
- [Lichtpult*Hier ist die Erklärung zu dem Lichtpult*](/licht/lichtpult)
{.links-list}
- [Daslight*DMX lighting software for PC*](/licht/daslight)
{.links-list}